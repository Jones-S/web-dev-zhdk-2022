console.info("Everything looks fine ✅.");
console.log("Open this script.js file and write your code...");

// write a function that multiplies three numbers
// that could be passed into the function as parameters (inputs)

// execute the function and log the result to the console.
