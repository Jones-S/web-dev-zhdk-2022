console.info("Everything looks fine ✅.");
console.log("Open this script.js file and write your code...");

// Select the div (blue box) in the index html and change its looks.
