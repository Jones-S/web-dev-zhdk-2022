console.info("Everything looks fine ✅.");
console.log("Open this script.js file and write your code...");

// Display either
// "The weather is sunny." when hovering the right box with the sun
// or
// "It is raining." when hovering the left box with the umbrella icon

// hints:
// select both boxes with JavaScript
// Add an eventlistener to register hovers
// Create a variable to save one of the two states
// and write a display function that displays the text inside
// the div '[data-js-weather]' depending on the variables value (condition)
